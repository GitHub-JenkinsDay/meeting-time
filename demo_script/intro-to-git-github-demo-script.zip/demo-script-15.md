and lastly, a great example of how to use GitHub wikis

  _https://github.com/netflix/Hystrix/wiki

sidebar navigation

  _click How it works

Diagrams
