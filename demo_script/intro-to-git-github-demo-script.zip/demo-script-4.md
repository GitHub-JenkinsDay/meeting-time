If you like, you can also edit the file

    _click the pencil icon_

GitHub provides a nicely rendered syntactic view of the content to help you when you’re editing.

    _click back_

    _click meeting-time_

    _click code tab_

Now for the social metadata

There are two primary mechanisms for communicating with the community around a repository.  Issues and Pull Requests

    _click issues_

here I can see all the open issues for this repository

Issues are like threaded discussions.  They can include things like

- Bug reports
- Feature requests
- General discussion
- Requests to do actual work in a repository

You can filter the view using these dropdowns

    _click Author dropdown_
    _click labels dropdown, select enhancement_
    _click enhancement again_

You can also select whether to view open or closed issues

    _click closed_

    _click open_

Let's drill down into an issue

    _click change default planet to Dagobah_
