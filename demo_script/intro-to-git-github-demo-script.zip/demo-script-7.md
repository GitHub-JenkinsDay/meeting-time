Clicking on the commits tab shows me the commits she made

    _click commits tab_

while clicking on the Files changed tab show’s me the files that were modified as well as the modifications that were made.  We’ll get into using Pull Requests in more detail in a bit.

    _click Files Changed_

We'll be creating a pull request in a bit...

#### Creating a repository

Time to simulate some actual work.  Let’s create a repository

    _click on the rebelware context_

I’m going to create a new repository in my rebel ware organization.

    _click new Repository_

We’ll give it a name…  Generally the more descriptive the better.

  _name it DellDemo_

Fill in a brief description

And specify whether we want the repository to be public or private.  This affects who can interact with the repository on GitHub Enterprise

Lastly, ALWAYS include a README file.  We talked about this :)

    _check Initialize with …_

That’s it, click Create Repository and you’re good to go

    _click Create REpository_

At the moment, only I have permissions to do anything in this repository.
It’s always more fun playing with others, so let’s add some collaborators…

    _click Settings then collaborators & teams_

I can add any teams that are part of my organization

    _click Select Team dropdown_
