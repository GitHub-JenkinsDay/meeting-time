and status

    _click open_

    _Use back to return to home page_

Note that when I switch my context to an organization, my search context changes to include only that organization
    _switch context to RebelWare_
    _show search box with This Organization_

Let’s try the same search again

    _search for meeting time_

Lots fewer results this time.

#### Repositories

let’s check out a repository

    _click meeting-time_

A repository on GitHub consists of two primary sets of information.

First is the code in the underlying Git repository

    _highlight the code_

and second is the social metadata that GitHub maintains around the code and the activity in the repository.
Stuff like issues and pull requests

You can click on a file to view it

    _click README.md_

You can see individual contributions to the file over time

    _click blame_

    _show revisions_

    _click normal view_

and you can view individual commits that included the file

    _click history_

    _click back_
