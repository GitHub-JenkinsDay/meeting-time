add emojis by typing a colon and selecting from the list!

    _type :_
    _select an emoji_

GitHub provides me with a list of folks who have access to this repository.  Just select the one you want!

    _select rey_

A good issue includes context as well, so let's reference another issue here to provide some background.

    _For background refer to #84_

    _click Update comment_

    _click Postman Comment 1_

Looks like Rey’s teammate Poe has offered to help.  This is the essence of collaboration on GitHub!

    _click postman comment 2_

Unfortunately it looks like Kylo over on the documentation team is not happy about maybe having to redo some work

Clearly conveying some pretty intense emotions…

    _click comment 3_

    _click comment 4_

You can even reference animated GIFs!!

Let’s take a look at a pull request

    _click pull requests tab_

    _click Update README.md_

Pull requests work a lot like issues as forums for communication.  Pull Requests, however, are centered around a set of commits, or proposed changes to the code.

You see what’s proposed at the top of the Pull Request.

    _highlight description_

Looks like Rey has made some changes on a feature branch, rey-patch1, and wants to merge them into production.

Note how her pull request describes what changes she’s proposed, a list of items to be completed before the change is shipped, as well as a link to the issue that proposed the change in the first place.
