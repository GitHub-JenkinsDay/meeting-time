Let’s bring in the Developers team with write permission…

    _do it_

And then bring in the documentation team with read permission

    _do it_

That’s all there is to that.  Now members of those teams can interact with my new repository

Next let’s look at editing and committing files using GitHub

    _click on code tab_

I’ll edit the README.md file so that’s it’s a little more useful..

    _click on README.me_

    _click on pencil icon_

Just add a little content….

This is the repository we used to demo for _Dell_.  It's fantastic!!

And then commit my changes

    _scroll down to commit changes_

Always remember to include useful commit messages and descriptions…

Add line describing the repository
To reflect how truly awesome it is!!

Note that I can commit this _directly_ to the master branch, but this means I won’t be able to create a pull request.

Instead, I’ll commit to a new branch

    _click Create a new branch…_

    _Click propose new change_

A pull request is automatically generated.

    _Click create pull request_

And now I’m ready to collaborate on this!!
