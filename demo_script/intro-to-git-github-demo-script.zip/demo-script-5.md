Looks like Admiral Ackbar wants some work done on the code to reflect recent changes in galactic geography.

He’s used some key features of GitHub to help him communicate this with the team.

Note the @ mention.  By @mentioning Rey, he’s generated a notification in her notification stream.

He's also included a task list to help whoever does the work keep track of what's been done

    _click a task element_

Note the liberal use of emoji.  Ever had a conflict with someone because of a  misunderstanding around an email or text?  Text can be dangerous.
Emojis help to convey non-verbal emotional context and humanize interactions.

BTW, by @mentioning the testing team, admackbar has let that entire team know they may be interested in this work.

Over on the right hand side he's assigned himself and Rey, a developer on the team, to this issue

You can assign folks by clicking on the assignees button

    _click assignees button_
    _add po_

I can also add labels, which help to organize issues and facilitate search.

    _click on Labels_

Labels are fully customizable, by the way.  You can create any number of them to help you
stay organized.

GitHub also provides a timeline showing activity related to the issue, including where it's been referenced in other locations
in GitHub.

Let's edit this issue for a bit to see how you can actually generate this content

    _click the pencil icon_

GitHub issues and pull requests support MarkDown.

MarkDown is basically a simplified markup language that gets rendered into HTML

Here's how to add an @ mention

    _delete @rey_

    _type @_
